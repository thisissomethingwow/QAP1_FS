//http is used to make http servers and http requsets in node.
//it lets you make web servers that can make requests and send responses 

//imports http and sets a port number
const http = require('http');
const port = 3000;


//makes a http server
const server = http.createServer((req,res)=>{
    res.writeHead(200,{'Content-Type':'text/plain'});
    //sends a responce to the user
    res.end('Hello world!')
    //sends a responce to the client when the server is accessed
    console.log("received")
})
//starts the server and listens for a user
server.listen(port,()=>{
    console.log('server is running at port 3000')
})
// path is used to work with file and direcotry paths 
// it can join, get the base name and the directory and the extension name

//import path
const path = require('path')


//setting the directory and file name
const directory = 'document/qap1_FS/';
const fileName = 'pathExample.js';

//joins together directory and file name
const filePath = path.join(directory,fileName);
console.log("file path:",filePath)

//gets the base of the file path
const base = path.basename(filePath)
console.log("file base", base)
//gets the directory of the file path
const test = path.dirname(filePath)
console.log("file base", test)
//gets the extension of the file path
const extname = path.extname(filePath)
console.log("file base", extname)

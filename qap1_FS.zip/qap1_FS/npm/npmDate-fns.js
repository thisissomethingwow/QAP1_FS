// this imports the function that you want to use 
import {format, addDays} from "date-fns";


//this set the date variable as today
const date = new Date();
//this changes the date to a later one by adding 675 days
const laterDate = addDays(date, 675)
//this formats the date to day/month/year
const fromatDate = format(date, 'dd/MM/yyyy')
//this gets the time
const time = format(date, 'h:mm:s')



console.log(date)
console.log(laterDate)
console.log(fromatDate)
console.log(time)
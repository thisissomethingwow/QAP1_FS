// fs uses API's to interact with the file systems and can read and write files. 
//it supports sync and async methodes 

//import http, fs and sets a port number

const http = require('http');
const fs = require('fs');
const port = 3000;

//makes a http server and displays the index.html file
const server  = http.createServer(function(req,res){
    fs.readFile('index.html',function(err,data){
        res.writeHead(200,{'Content-Type': 'text/html'});
        res.write(data);
        return res.end
    })
})
//starts the server and listens for a user
server.listen(port,()=>{
    console.log('server is running at port 3000')
})

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              